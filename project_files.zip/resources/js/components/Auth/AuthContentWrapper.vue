<template>
    <div class="flex items-center justify-center px-2.5 md:px-6">
        <slot></slot>
    </div>
</template>

<script>
export default {
    name: 'AuthContentWrapper',
}
</script>
