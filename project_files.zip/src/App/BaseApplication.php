<?php
namespace App;

use Illuminate\Foundation\Application;

class BaseApplication extends Application
{
    protected $namespace = 'App\\';
}
